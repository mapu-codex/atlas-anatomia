# Atlas Anatómico — Licencias y prueba WebXR v0.12.1

## Resultado de revisión (23 oct 2026)

- Z-Anatomy: licencia base CC BY-SA 4.0; reconoce datos de BodyParts3D CC BY-SA 2.1 Japón en su documento `License.txt`.
- Excepciones identificadas por Z-Anatomy: nervios craneales y agujeros del cráneo de University of Dundee (CC BY 4.0), oído interno de Dundee (CC BY-NC-SA 4.0), riñón de Lissie Cowley (CC BY-NC 4.0). No se debe atribuir una licencia uniforme a todos los modelos.
- La capa experimental `ligamentos_DEPURADOS_NO_PUBLICAR.glb` no está lista para publicación: una inspección del JSON glTF encuentra todavía nodos denominados `Liver`, `Intermediate tendon of digastric muscle`, `Plantar aponeurosis` y `Articular disc of distal radio-ulnar joint` que quedaron en el archivo aun si se excluyeron de la escena principal. Es necesario limpiar los recursos huérfanos y verificar cada pieza de procedencia dudosa antes de redistribuir.
- Conclusión: las licencias base favorecen reutilización con atribución y compartir adaptaciones, PERO no se ha terminado el inventario de procedencia por pieza de la capa nueva. Esta prueba VR no contiene modelos anatómicos de terceros.

Fuentes:
- https://github.com/Z-Anatomy/Models-of-human-anatomy/blob/master/License.txt
- https://github.com/SeemaBansal1/3d-human-body-anatomy
- https://developers.meta.com/vr/documentation/web/webxr-overview/
- https://developers.meta.com/vr/documentation/web/port-vr-xr/

## Prueba paso a paso con Meta Quest 3S

1. Con el visor de tu profesora disponible, prueba primero el HTML en PC usando VS Code y Live Server para ver la figura simplificada.
2. Para probar WebXR **dentro del Quest**, usa una página con HTTPS. En tu repositorio actual `mapu-codex/atlas-anatomia` puedes cargar **solo** `prueba-vr.html` como archivo independiente. No reemplaces `index.html` ni subas ningún GLB.
3. En GitHub, entra a ese repositorio, selecciona `Add file` > `Upload files`, arrastra `prueba-vr.html` y confirma el commit. Esto es una acción que realizas tú; el asistente no sube archivos.
4. Espera a que GitHub Pages publique el cambio y, desde el navegador del Quest 3S, abre `https://mapu-codex.github.io/atlas-anatomia/prueba-vr.html`.
5. Comprueba si el botón cambia a `Entrar en VR`. Entra; verás seis piezas de colores formando una figura esquemática delante de ti. Apunta a una pieza con el controlador y presiona el gatillo.
6. Dime si: a) apareció `Entrar en VR`; b) entraste en modo inmersivo; c) viste la figura y d) pudiste seleccionar usando el controlador.

**Avisos:** la primera prueba no valida la aplicación anatómica completa ni compatibilidad definitiva con los modelos GLB. No hagas esta prueba caminando por la habitación: mantente en un área despejada, respetando los límites de seguridad del visor. Se requiere Internet en el visor para cargar Three.js por CDN.
